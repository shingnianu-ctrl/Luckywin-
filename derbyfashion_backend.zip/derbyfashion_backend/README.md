# DerbyFashion backend

Use these files for the Node/Express backend.

Render:
- Runtime: Node
- Build Command: npm install
- Start Command: npm start
- Environment variable: RUPAYEX_TOKEN = your NEW API token

Never put the token in index.html or commit it to GitHub.

Endpoints:
- POST /create-order
- GET /order-status?order_id=...

The provider endpoints/fields are based on the API documentation screenshot supplied in the conversation. Test the provider response before changing the frontend checkout logic.
